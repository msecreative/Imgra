<?php
/*
Plugin Name: smXpro Helper
Description: smXpro Helper is the core plugin for smXpro WordPress Theme. You must install this plugin to get a full fledge smXpro WordPress Theme, otherwise you'll miss some cool features.
Plugin URI: http://mt.lab.themebucket.net/
Author: Majestic Theme
Author URI: http://mt.lab.themebucket.net/
Version: 1.0.0
License: GPL2
Text Domain: smXpro
Domain Path: /languages
*/

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    die( 'No Direct Access' );
}

/*******************************************************************
 * Constants
 *******************************************************************/

/** smXpro Engine version  */
define( 'SMXPRO_HELPER_VERSION', '1.0.0' );

/** smXpro Engine directory path  */
define( 'SMXPRO_HELPER_DIR', trailingslashit( plugin_dir_path( __FILE__ ) ) );

/** smXpro Engine includes directory path  */
define( 'SMXPRO_HELPER_INCLUDES_DIR', trailingslashit( SMXPRO_HELPER_DIR . 'includes' ) );

/** smXpro Engine shortcodes directory path  */
define( 'SMXPRO_HELPER_SHORTCODES_DIR', trailingslashit( SMXPRO_HELPER_DIR . 'shortcodes' ) );

/** smXpro Engine url  */
define( 'SMXPRO_HELPER_URL', trailingslashit(  plugin_dir_url( __FILE__ ) ) );


class smXpro_Helper {

    public function __construct() {
        register_activation_hook( __FILE__, array($this, 'activate') );

        $this->load_includes();

        $this->load_shortcodes();

        add_action( 'plugins_loaded', array($this, 'load_textdomain') );
    }

    public function activate() {
        // flash rewrite rules because of custom post type
        flush_rewrite_rules();
    }

    public function load_textdomain() {
        load_plugin_textdomain( 'smXpro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    }

    private function load_includes() {
        // shortcode base
        require_once  SMXPRO_HELPER_INCLUDES_DIR . 'class.shortcode.php';

    }

    /**
     * Include all shortcode files
     * @return null
     */
    private function load_shortcodes() {
        foreach ( glob( SMXPRO_HELPER_SHORTCODES_DIR . '*/*.php' ) as $shortcode ) {
            if ( ! file_exists( $shortcode ) ) {
                continue;
            }
            require_once $shortcode;
        }
    }

}

new smXpro_Helper;
