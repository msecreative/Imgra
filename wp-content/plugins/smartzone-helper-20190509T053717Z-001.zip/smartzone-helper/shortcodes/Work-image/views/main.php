<?php
$image = $atts['img'];
$all_service_link  = $atts['all_service_link'];

?>

   <!--    [ START SERVICES AREA]-->
<div class="single-brand-item">
    <a href=""><img src="<?php echo wp_get_attachment_image();?>" alt=""></a>
</div>
                <!--    [Finish Single Service Item]-->



