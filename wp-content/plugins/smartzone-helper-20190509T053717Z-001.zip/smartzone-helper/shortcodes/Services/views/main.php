<?php
$logo = $atts['logo'];
$Service_title  = $atts['service_title'];
$Service_des  = $atts['service_des'];
$all_service_link  = $atts['all_service_link'];

?>

   <!--    [ START SERVICES AREA]-->
    		<div class="services-area">
                <!--    [ Start Single Service Item]-->
                <div class="wow fadeIn">
                    <div class="single-service-item">
                        <i class="fa fa-laptop"></i>
                        <h4><?php echo esc_html($Service_title)?></h4>
                        <p><?php echo esc_html($Service_des)?></p>
                        <a href="" class="service-btn"><?php echo esc_html($all_service_link) ?> <i class="fa fa-long-arrow-right"></i></a>
                    </div>                </div>

            </div>
                <!--    [Finish Single Service Item]-->



