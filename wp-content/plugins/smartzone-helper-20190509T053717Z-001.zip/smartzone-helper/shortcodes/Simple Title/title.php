<?php
/**
 * smXpro Title text shortcode
 *
 * @package smXpro_Helper
 * @author Smart Coder <smartcoderbd@gmail.com>
 */

class smXpro_title extends Smartzone_Shortcode {

    /**
     * Set shortcode tag
     * @var string
     */
    protected $tag = 'smXpro_title';

    /**
     * Set shortcode directory
     * @return string Directory path
     */
    protected function set_dir() {
        return __DIR__;
    }

    /**
     * Map this shortcode with visual composer
     * @return array
     */
    protected function map() {
        return array(
		        $this->tag => array( // <-- shortcode tag name

                    'name'                 => esc_html__('Text Title', 'smXpro'),
                    'description'          => esc_html__('SmXpro Title with Subtitle', 'smXpro'),
                    'icon'                 => 'fa-comments-o',
                    'category'             => 'SmXpro',
                    'params'               => array(
                    'general'          => array(

                            array(
                                'name' => 'title',
                                'label' => esc_html__('Title 1 ','smXpro'),
                                'type' => 'text',  // USAGE SELECT TYPE
                                'description' => esc_html__( 'Add Title','smXpro'),
                            ),
                            array(
                                'name' => 'title2',
                                'label' => esc_html__('Title 2','smXpro'),
                                'type' => 'text',  // USAGE SELECT TYPE
                                'description' => esc_html__( 'Add Title 2','smXpro'),
                            ),            
                          
                            array(
                                'name'        => 'custom_css_class',
                                'label'       => esc_html__('CSS Class','smXpro'),
                                'description' => esc_html__('Custom css class for css customisation','Smartzone'),
                                'type'        => 'text'
                                        ),
                            ),// general

                    )// Params

                )// end shortcode key
            );// first array
    }
    /**
     * render this shortcode
     * @param  array $atts
     * @param  string $content
     * @return string
     */
    public function render( $atts, $content = null ) {
            $defaults = array(
                'title'                  => '',
                'title2'                   => '',
                'custom_css_class'        => '',
                'custom_css'              => '',
            );

        $short_atts = shortcode_atts( $defaults, $atts );
        $view = $this->get_view( 'main' );
        extract($short_atts);
        //custom class
        $wrap_class  = apply_filters( 'kc-el-class', $atts );
        if( !empty( $custom_css_class ) ):
            $wrap_class[] = $custom_css_class;
        endif;
        $extra_class =  implode( ' ', $wrap_class );

        ob_start();
        if (file_exists( $view ) ) {
            include( $view );
        }
        return ob_get_clean();

    }

}

new smXpro_title;
