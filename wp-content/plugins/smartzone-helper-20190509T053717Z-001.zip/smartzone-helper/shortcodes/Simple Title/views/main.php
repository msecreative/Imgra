<?php
$title1 = $atts['title'];
$title2  = $atts['title2'];
?>

<div class="section-title">
                        <h3><?php echo esc_html($title1)?> <span><?php echo esc_html($title2)?></span></h3>
                    </div>



